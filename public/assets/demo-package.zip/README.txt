Little Office demo fixtures
Landscape H.264/AAC 1920x1080, sekitar 20 detik.
Target workflow 60 detik; klip preview lebih pendek.
Media tersedia lokal, tidak diunggah ke YouTube.
Caption timing adalah contoh.
Office art: Bumi openai/gpt-image-2. Narasi: macOS Damayanti, dibuat lokal.
